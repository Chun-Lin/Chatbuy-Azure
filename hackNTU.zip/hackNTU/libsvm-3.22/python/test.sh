python hackTest.py chien_yi /Users/chienyi/hackNTU/test_data/chien_yi.mp3
