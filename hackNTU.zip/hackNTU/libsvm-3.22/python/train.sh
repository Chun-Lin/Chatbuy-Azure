python hackTrain.py chien_yi
