python SpeechRecog.py /Users/chienyi/hackNTU/chien_yi01.wav
